[mappings: [],
 translations: []]